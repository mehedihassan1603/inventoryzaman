<?php

namespace App\Contracts\Sms;

interface CheckBalanceInterface
{
    public function balance();
}