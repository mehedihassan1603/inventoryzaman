<?php

namespace App\Models;

class Model
{

}
