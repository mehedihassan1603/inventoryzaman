<?php

namespace App\Models;

trait HasFactory
{

}
